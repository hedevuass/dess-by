<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/src/css/main.css">
    <link rel="stylesheet" href="/src/css/banner.css">
    <title>Document</title>
</head>
<body>
    <?php include('header.php'); ?>
    <div class="banner">
    <div class="banner__container">
        <div class="banner__card">
            <img src="/src/img/paneli.jpg" alt="Product 1">
            <h3 class="banner__card-title">Сотовые панели</h3>
            <p class="banner__card-description">Сотовые панели представляют собой трехслойные изделия, состоящие из одного внутреннего слоя - сотового картонного заполнителя с шестигранной формой ячеек и двух плоских наружных слоев картона, приклеенных к заполнителю с обеих сторон клеем ПВА.</p>
            <p class="banner__card-price">Цена: $19.99</p>
            <a href="#" class="banner__card-button">Подробнее</a>
        </div>
        <div class="banner__card">
            <img src="/src/img/box.jpg" alt="Product 2">
            <h3 class="banner__card-title">Упаковки</h3>
            <p class="banner__card-description">Упаковка из сотового картона - это надежная упаковочная тара, гарантирующая защиту продукции. Альтернативная замена деревянной и пластмассовой упаковке. Особенно востребованы коробки и ящики из сотового картона.</p>
            <p class="banner__card-price">Цена: $24.99</p>
            <a href="#" class="banner__card-button">Подробнее</a>
        </div>
        <div class="banner__card">
            <img src="/src/img/poddon.jpg" alt="Product 3">
            <h3 class="banner__card-title">Поддоны</h3>
            <p class="banner__card-description">Поддоны из сотового картона - отличный вариант для тех, кто хочет сэкономить на доставке и утилизации тары. Сами по себе они легче и дешевле аналогов из дерева и пластика, но не уступают им по способам применения и прочности.</p>
            <p class="banner__card-price">Цена: $29.99</p>
            <a href="#" class="banner__card-button">Подробнее</a>
        </div>
    </div>
</div>
<?php include('footer.php'); ?>
</body>
</html>