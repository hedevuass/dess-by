<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/src/css/main.css">
    <title>Document</title>
</head>

<body>
    <header>
        <div class="header-logo-name">
            Honeycomb Cardboard
        </div>
    </header>
</body>

</html>